function grid = inject(grid,pattern,x,y)
% 	INJECT   inject pattern into grid at position x, y
% 		[GRID] = INJECT(GRID,PATTERN,X,Y)
% 
% 	inject pattern into grid at position x, y
% 	
% 	Created by Fabián Cañas on 2011-04-12

[w,h] = size(pattern);
grid(x:(x+w-1),y:(y+h-1))=pattern;

end %  function