function grid = life(grid)
% 	LIFE   outputs the next step to a game of life
% 		[GRID] = LIFE(GRID)
% 
% 	Outputs the next step of conway's life
% 	
% 	Created by Fabián Cañas on 2011-04-12.

% Number of neighbours:
neighbours = conv2(grid,[1 1 1; 1 0 1; 1 1 1],'same');

% Any live cell with fewer than two live neighbours dies, as if caused by under-population.
grid(neighbours<2) = 0;
% Any live cell with more than three live neighbours dies, as if by overcrowding.
grid(neighbours>3) = 0;
% Any dead cell with exactly three live neighbours becomes a live cell, as if by reproduction.
grid(neighbours==3) = 1;

% Any live cell with two or three live neighbours lives on to the next generation.
% free

end %  function