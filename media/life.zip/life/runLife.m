function runLife(scene)
% 	RUNLIFE   Runs the game of life 'scene' in a window
% 		[OUTPUT VARIABLES] = RUNLIFE(SCENE)
% 
% 	Runs the provided scene in the game of life.
%  Input is a 2D matrix.
%  Running terminates when two sequential steps are identical.
%  Life is not run on a torus.
% 	
% 	Created by Fabián Cañas on 2011-04-12.

g = scene;
figure
colormap('gray')
axis off
i = 0;
while true
	i = i + 1;
	image(g*255);
	axis equal
	gp = life(g);
	drawnow
	% print(gcf, '-dtiff', '-r100', sprintf('image_%04d', i));
	if gp==g
		break;
	end
	g = gp;
end

end %  function