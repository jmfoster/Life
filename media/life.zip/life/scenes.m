function scene = scenes(name)
% 	SCENES   A library of Life scenes
% 		[SCENE] = SCENES(NAME)
% 
% 	This is a repository for Life scenes. Given a name, it will return the starting point for the named scene
% 	
% 	Created by Fabian Canas on 2011-04-13.

switch name
	case 'lonely-planet'
		g = zeros(21);
		g = inject(g,zoo('toad'),3,2);
		g = inject(g,zoo('pulsar'),3,8);
		g = inject(g,zoo('mold'),16,3);
		g = inject(g,zoo('block'),10,2);
		scene = g;
    case 'acorn'
		g = zeros(50);
		g = inject(g,zoo('acorn'),20,23);
		scene = g;
	case 'glider-eater'
		g = zeros(50);
		g = inject(g,zoo('gosper-gun'), 2, 5);
		g = inject(g,zoo('eater-1'),25,42);
		scene = g;
	otherwise
		scene = zoo('toad');
end




end %  function