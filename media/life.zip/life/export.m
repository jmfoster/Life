function export(scene, file)
% 	EXPORT   Exports a scene to a file suitable for simulation
% 		[OUTPUT VARIABLES] = EXPORT(SCENE, FILE)
% 
% 	Exports a scene to a file suitable for simulation
%  FILE is a file string
%  SCENE is a _square_ 2d matrix.
%  Other input will fail
% 	
% 	Created by Fabián Cañas on 2011-06-23.

fid = fopen(file,'w')

[n,m]=size(scene);
fprintf(fid,'%d\n',n);

s = regexprep(regexprep(regexprep(mat2str(scene),' ',','),';','\n'),'[\]\[]','');
fprintf(fid,s);

fclose(fid);

end %  function